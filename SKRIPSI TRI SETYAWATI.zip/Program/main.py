from flask import Flask, flash, render_template, request, current_app, send_file, send_from_directory
from werkzeug.utils import secure_filename
import datetime, numpy, cv2 as cv, hashlib, math, qrcode, os, PyPDF2, fitz, time, glob
from sympy import GF, invert
from sympy import ZZ, Poly
from sympy.abc import x
from PIL import Image

app = Flask(__name__)
app.config['UPLOAD_FOLDER']='static'
app.secret_key = "secret key"
# app.config['current_app']= 'C:\Users\tris\myproject'
ALLOWED_EXTENSION = set(['pdf','npz'])

filename = None
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSION
def random_poly(length, d, neg_ones_diff=0):
    return Poly(numpy.random.permutation(numpy.concatenate((numpy.zeros(length - 2 * d - neg_ones_diff), numpy.ones(d), -numpy.ones(d + neg_ones_diff)))),x).set_domain(ZZ)        
def random_poly2(length, d, neg_ones_diff=0):
    return Poly(numpy.random.permutation(numpy.concatenate((numpy.zeros(length - 2 * d - neg_ones_diff), numpy.ones(d)))),x).set_domain(ZZ)        
def showpoly(a):
    m = ""
    nobits = len(a)
    for x in range (0, nobits-2):
        if (a[x] == '1'):
            if (len(m) == 0):
                m += "x**"+str(nobits-x-1)
            else:
                m += "+x**"+str(nobits-x-1)
        if (a[x] != '1' != '0' ):
            if (len(m) == 0):
                m += str(a[x])+"*x**"+str(nobits-x-1)
            else:
                m += "+"+ str(a[x]) +"*x**"+str(nobits-x-1)
    if (a[nobits - 2] == '1'):
        if (len(m) == 0):
            m += "x"
        else: 
            m += "+x"
    if (a[nobits - 2] != '0' != '1'):
        if (len(m) == 0):
            m += str(a[nobits - 2])+"*x"
        else: 
            m += "+"+ str(a[nobits - 2]) +"*x"
    if (a[nobits - 1] == '1'):
        m += "+1"
    if (a[nobits - 1] != '0' != '1'):
        m += "+"+str(a[nobits - 1])
    return Poly(m);
def is_prime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True
def is_2_power(n):
    return n != 0 and (n & (n - 1) == 0)
def invert_poly(f, R_poly, a):
    if is_prime(a):
        inv_poly = invert(f, R_poly, domain=GF(a))
    elif is_2_power(a):
        inv_poly = invert(f, R_poly, domain=GF(2))
        e = int(math.log(a,2))
        for i in range (1, e):
            inv_poly = ((2 * inv_poly - f * inv_poly ** 2) % R_poly).trunc(a)
    else:
        raise Exception("Cannot")
    return inv_poly            
def cek(hex_string,hex_hash_teks):
            hasil = ""
            if(hex_string[2:] == hex_hash_teks):
                hasil = "Sertifikat Valid"
            else:
                hasil = "Sertifikat Tidak Valid"
            return hasil

@app.route('/')
def home():
    return render_template("template.html")

@app.route("/run")
def run():
    key =['251','3','2048']#n=587
    start_gen = time.time()
    n = int(key[0])
    p = int(key[1])
    q = int(key[2])
    g = random_poly(int(key[0]), int(math.sqrt(int(key[2]))))
    f = random_poly(int(key[0]), int(key[0]) // 3, neg_ones_diff=-1)
    R_poly = Poly(x**n-1, x).set_domain(ZZ) 
    f_p = invert_poly(f, R_poly, p)
    f_q = invert_poly(f, R_poly, q)
    p_f_q = (p * f_q).trunc(q)
    h_before_mod = (p_f_q * g).trunc(q)
    h = (h_before_mod % R_poly).trunc(q)
    end_gen = time.time()
    keyname = "_".join(["key","public","private.npz"])
    numpy.savez(os.path.join(app.config['UPLOAD_FOLDER'], f'{keyname}'), polyg = g, polyf = f, polyfp = f_p, polyfq = f_q, polyh = h, n = int(key[0]), p = int(key[1]), q = int(key[2]))   
    print("Public Key :\n")
    print("H :\n",h)
    print("Private Key :\n")
    print("F :\n",f)
    print("Fp :\n",f_p)
    print("Fq :\n",f_q)
    print(f"Runtime of encrypt is {end_gen - start_gen}")

    flash(keyname)    
    return render_template("template.html",scroll='scrollspyHeading2')

@app.route("/runscript", methods=["POST","GET"])
def run_script():
    if request.method == 'POST':
        if 'files[]' not in request.files:
            flash('No file part')
            return render_template("template.html")
        files = request.files.getlist('files[]')
        uploadfile = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            uploadfile.append(filename)
        print(uploadfile[0])
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]), allow_pickle=True) as data:
            polyh = data['polyh']
            n = data['n']
            q = data['q'] 
        R_poly = Poly(x**n-1, x).set_domain(ZZ)
        start_enc = time.time()
        pdffile = open(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]), 'rb')
        pdfReader = PyPDF2.PdfFileReader(pdffile)
        pageObj = pdfReader.getPage(0)
        teks = pageObj.extractText()
            #--------------------- HASHING TEKS ------------------------
        hash_teks = hashlib.sha512(teks.encode())
        hex_hash_teks = hash_teks.hexdigest()
        R_poly = Poly(x**n-1, x).set_domain(ZZ) 
            #--------------------- RANDOM POLYNOMIAL R ------------------------
        r = random_poly2(n, int(math.sqrt(q)))
            #-------------------- MAPPING HASH TO POLYNOMIAL -----------------------------
        nn = int(hex_hash_teks, 16)
        bStr = ''
        while nn > 0:
            bStr = str(nn % 2) + bStr
            nn = nn >> 1	
        rest = bStr
        mes = showpoly(rest)
            #------------------------ ENCRYPT MESSAGE ---------------------
        h = polyh
        e = (((r * h).trunc(q) + mes ) % R_poly).trunc(q)
            #------------------------ SAVE .NPZ ----------------------------
        suffix = datetime.datetime.now().strftime("%y%m%d_%H%M%S.npz")
        suffix2 = datetime.datetime.now().strftime("%y%m%d_%H%M%S.png")
        suffix3 = datetime.datetime.now().strftime("%y%m%d_%H%M%S.pdf")
        keynamee = "_".join(["encrypted",suffix])
        newfilename = "_".join([uploadfile[0].rsplit('.',1)[0].lower(),"new", suffix3])
        numpy.savez(os.path.join(app.config['UPLOAD_FOLDER'], f'{keynamee}'), polye = e)   
                #------------------------- QR Code ----------------------------
        nameqrcode = "_".join(["qr", filename.rsplit('.',1)[0].lower(), suffix2])
        qr = qrcode.make(f'{keynamee}')
        qr.save(f"{nameqrcode}")
        image_rectangle = fitz.Rect(20,450,120,550)
        file_handle = fitz.open(pdffile)
        first_page = file_handle[0]
        first_page.insert_image(image_rectangle, filename = nameqrcode)
        file_handle.save(os.path.join(app.config['UPLOAD_FOLDER'], newfilename)) 
        end_enc = time.time()
            #----------------- PRINT ----------------
        print("Pesan :\n", teks)
        print("Message Digest :\n",hex_hash_teks)
        print("Binary :\n", rest)
        print("h :\n", h)
        print("r :\n", r)
        print("Polynomial :\n", mes)
        print("Encrypted :\n",e)
        print("Key File :\n", keynamee)
        print(f"Runtime of encrypt is {end_enc - start_enc}")
        pdffile.close()
        flash(newfilename)
        return render_template("template.html",scroll='scrollspyHeading3')
    return render_template("template.html",scroll='scrollspyHeading3')

@app.route("/runscriptdec", methods=['POST'])
def run_scriptdec():
    if request.method == 'POST':
        if 'filesdec[]' not in request.files:
            flash('No file part')
            return render_template("template.html")
        files = request.files.getlist('filesdec[]')
        uploadfile = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            uploadfile.append(filename)
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]), allow_pickle=True) as data:
            polyf = data['polyf']
            polyfp = data['polyfp']
            n = data['n']
            p = data['p']
            q = data['q'] 
        print(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]))     
        R_poly = Poly(x**n-1, x).set_domain(ZZ)
        start_dec = time.time()
        pdf = open(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]), 'rb')
        pdfFile = fitz.open(pdf)
        pdfReader = PyPDF2.PdfFileReader(pdf)
        pageObj = pdfReader.getPage(0)
        teks = pageObj.extractText()
                #--------------- Get QR-Code from PDF ----------------
        number_of_page = len(pdfFile)
        for current_page_index in range(number_of_page):
            for img_index, img in enumerate(pdfFile.getPageImageList(current_page_index)):
                xref = img[0]
                image = fitz.Pixmap(pdfFile, xref)
                if image.n < 5:
                    image.writePNG(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
                else:                
                    new_image = fitz.Pixmap(fitz.csRGB, image)
                    new_image.writePNG(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        img = cv.imread(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        det = cv.QRCodeDetector()
        val, pts, st_code = det.detectAndDecode(img)
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], val), allow_pickle=True) as datas:
            polye = datas['polye']
                #-------------------- olah dari qr --------------------------
        a = ((polyf * polye) % R_poly).trunc(q)
        b = a.trunc(p)
        m_before_mod = ((polyfp * b) % R_poly)
        m = Poly(m_before_mod, x, domain=GF(p, symmetric=False))
        me = Poly(m, x).set_domain(ZZ)
        men = me.rep.rep
        for i in range(len(men)):
            if (men[i] == 0):
                men[i] = 0
            else:
                (men[i]) = 1
        biner =''.join(map(str, men))
        des = int(str(biner),2)
        hex_string = hex(des)
                #--------------Hashing Text --------------------------
        hash_teks = hashlib.sha512(teks.encode())
        hex_hash_teks = hash_teks.hexdigest()
                #----------------------Compare Hash---------------------
        cekhasil = cek(hex_string, hex_hash_teks)
        end_dec = time.time()
        print("Pesan :\n", teks)
        print("f :\n", polyf)
        print("fp-1 :\n", polyfp)
        print("Isi QR-Code :\n", val)
        print("a :\n", a)
        print("d :\n", b)
        print("me :\n", me)
        print("men :\n", men)
        print("biner :\n", biner)
        print("des :\n", des)
        print("Rujukan link QR-Code :\n", polye)
        print("Message Digest :\n", hex_hash_teks)
        print("Decryption Result :\n", hex_string)
        print("Verification Result: \n", cekhasil)
        print(f"Runtime of encrypt is {end_dec - start_dec}")
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]))
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        flash(cekhasil)
        return render_template("template.html",scroll='scrollspyHeading4')

@app.route("/download", methods=['GET', 'POST'])
def download():
    if request.method == 'POST':
        filename = request.form['form']
        uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'],filename)
    return send_file(uploads,as_attachment=True)
   
@app.route("/delete", methods=['GET', 'POST'])
def delete():
    uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'])
    for file in os.scandir(uploads):
        os.remove(file.path)
    return render_template("template.html",**locals())

if __name__ == "__main__":
    app.run(debug=True)