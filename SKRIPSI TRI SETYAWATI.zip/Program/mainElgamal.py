from flask import Flask, flash, render_template, request, current_app, send_file, send_from_directory
from werkzeug.utils import secure_filename
import datetime, random, numpy, cv2 as cv, hashlib, math, qrcode, os, PyPDF2, fitz, time, glob
from PIL import Image

app = Flask(__name__)
app.config['UPLOAD_FOLDER']='static'
app.secret_key = "secret key"
# app.config['current_app']= 'C:\Users\tris\myproject'
ALLOWED_EXTENSION = set(['pdf','npz', 'npy'])

filename = None
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSION
def SS(num, icon):
    for i in range(icon):
        a = random.randint(1,num-1)
        if gcd(a, num)>1:
            return False
        # if not jacobi(a, num) % num == modexp(a,(num-1)//2, num):
        #     return False
    return True
def find_prime(nbits, icon):
    while(1):
        p = random.randint(2**(nbits-2), 2**(nbits-1))
        while(p%2 == 0):
            p = random.randint(2**(nbits-2), 2**(nbits-1))
        while(not SS(p,icon)):
            p = random.randint(2**(nbits-2),2**(nbits-1))
            while(p%2 == 0):
                p = random.randint(2**(nbits-2), 2**(nbits-1))
        p = p*2+1
        if miller_rabin(p):
            return p
def miller_rabin_pass(a, s, d, n):
    a_to_power = pow(a, d, n)
    i = 0
    if a_to_power == 1:
        return True

        
    while(i < s-1):
        if a_to_power == n - 1:
            return True
        a_to_power = (a_to_power * a_to_power) % n
        i += 1

        # if the test failed until i=s-2
    return a_to_power == n - 1
def miller_rabin(n):
        # if n pass rabinmiller test hingga k random bases
        # n-1 = (2^s)d
    d = n-1
    s = 0
    while d % 2 == 0:
        d >>= 1
        s += 1

        # K times
        # false positive < (1/4)^K
    K = 20

    i = 1
    while(i <= K):
            # 1 < a < n-1
        a = random.randrange(2, n-1)
        if not miller_rabin_pass(a, s, d, n):
            return False
        i += 1

    return True

#To fing gcd of two numbers
def gcd(a, b):
    '''
    2.8 times faster than egcd(a,b)[2]
    '''
    a, b = (b, a) if a < b else (a, b)
    while b:
        a, b = b, a % b
    return a
def modexp( base, exp, modulus ):
	return pow(base, exp, modulus)
def find_primitive_root(p):
    if p == 2:
        return 1
    p1 = 2
    print("type p:",type(p))
    p2 = (p-1)//p1
    while(1):
        g = random.randint(2, p-1)
        if not(modexp(g, (p-1)//p1, p) == 1):
            if not modexp(g, (p-1)//p2, p) == 1:
                return g
def gen_key(nbits = 1024, icon = 10): #icon = iterasi di SS (?)
    # start_key_pub = time.time()
    p = find_prime(nbits, icon)
    g = find_primitive_root(p)
    g = modexp(g,2,p)
    # start_key_priv = time.time()
    x = random.randint(1,(p-1)//2)
    # end_key_priv = time.time()
    # time_key_priv = end_key_priv - start_key_priv
    h = modexp(g,x,p)
    # end_key_pub = time.time()
    # print(f"Runtime of public key generate is {end_key_pub - start_key_pub - time_key_priv}")
    # print(f"Runtime of private key generate is {end_key_priv - start_key_priv}")
    return p,g,h,x, nbits
def encode(plain,nbits):
    byte_array = bytearray(plain,'utf-16')
    z = []
    k = nbits//8
    j = -1*k
    num = 0
    for i in range(len(byte_array)):
        if i%k == 0:
            j += k
            num = 0
            z.append(0)
        z[j//k] += byte_array[i]*(2**(8*(i%k)))
    return z
def decode(aplain, nbits):
    bytes_array = []
    k = nbits//8
    for num in aplain:
        for i in range(k):
            temp = num
            for j in range(i+1, k):
                temp = temp%(2**(8*j))
            letter = temp//(2**(8*i))
            # print("letter:", letter)
            bytes_array.append(letter)
            num = num-(letter*(2**(8*i)))
    print("bytes array:", bytes_array)
    decodeText = bytearray(b for b in bytes_array).decode('utf-16')
    return decodeText
def encryption(msg,p,h,g, nbits):
    z = encode(msg,nbits)
    print("z:",z)
    print(type(z))
    cipher_pairs=[]
    for i in z:
        y = random.randint(0,p)
        c = modexp(g,y,p)
        i = int(i)
        print("cPair:",c)
        print("i:",i)
        print("type i:", type(i))
        print("h:", h)
        print("type h:",type(h))
        print("y:",y)
        print("p:",p)
        # t = modexp(h,y,p)
        d = (i*modexp(h,y,p)%p)
        print("dPair:",d)
        cipher_pairs.append([c,d])
    encryptedStr = ""
    for pair in cipher_pairs:
        encryptedStr += str(pair[0])+' '+str(pair[1])+' '
    return encryptedStr
def decryption(e,x,p,nbits):
    pt=[]
    cipherArray = e.split()
    print("cipherArray:",cipherArray)
    # h=power(p,key,q)
    if (not len(cipherArray)%2 == 0):
        return "Malformed Cipher Text"
    for i in range(0,len(cipherArray),2):
        # pt.append(chr(int(ct[i]/h)))
        c = int(cipherArray[i])
        print("c:",c)
        d = int(cipherArray[i+1])
        print("d:",d)
        s = modexp(c,x,p)
        plain = (d*modexp(s,p-2,p))%p
        print("plain:",plain)
        pt.append(plain)
    decryptedText = decode(pt, nbits)
    decryptedText = "".join([ch for ch in decryptedText if ch != '\x00'])
    print("dectext:\n",decryptedText)
    return decryptedText


def cek(hex_string,hex_hash_teks):
    hasil = ""
    if(hex_string == hex_hash_teks):
        hasil = "Sertifikat Valid"
    else:
        hasil = "Sertifikat Tidak Valid"
    return hasil

@app.route('/')
def home():
    return render_template("template.html")

@app.route("/run")
def run():
    p,g,h,x,nbits = gen_key()
    keyname = "_".join(["key","elgamal.npz"])
    numpy.savez(os.path.join(app.config['UPLOAD_FOLDER'], f'{keyname}'), p = p, g = g, h = h, x = x, nbits = nbits)   
    print("p :\n",p)
    print("g :\n",g)
    print("h :\n",h)#diskripsi = y
    print("x :\n",x)#privat key
    print("nbits :\n",nbits)

    flash(keyname)    
    return render_template("template.html",scroll='scrollspyHeading2')

@app.route("/runscript", methods=["POST","GET"])
def run_script():
    if request.method == 'POST':
        if 'files[]' not in request.files:
            flash('No file part')
            return render_template("template.html")
        files = request.files.getlist('files[]')
        uploadfile = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            uploadfile.append(filename)
        print(uploadfile[0])
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]), allow_pickle=True) as data:
            p = data['p']
            h = data['h']
            g = data['g']
            nbits = data['nbits'] 
        p = int(p)
        h = int(h)
        g = int(g)
        nbits = int(nbits)
        pdffile = open(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]), 'rb')
        pdfReader = PyPDF2.PdfFileReader(pdffile)
        pageObj = pdfReader.getPage(0)
        teks = pageObj.extractText()
            #--------------------- HASHING TEKS ------------------------
        hash_teks = hashlib.sha512(teks.encode())
        hex_hash_teks = hash_teks.hexdigest()
            #------------------------ ENCRYPT MESSAGE ---------------------
        e = encryption(hex_hash_teks,p,h,g, nbits)
        print("pesan terenkripsi:",e)
        print(type(e))
            #------------------------ SAVE .NPZ ----------------------------
        suffix = datetime.datetime.now().strftime("%y%m%d_%H%M%S.npz")
        suffix2 = datetime.datetime.now().strftime("%y%m%d_%H%M%S.png")
        suffix3 = datetime.datetime.now().strftime("%y%m%d_%H%M%S.pdf")
        keynamee = "_".join(["encryptedElgamal",suffix])
        newfilename = "_".join([uploadfile[0].rsplit('.',1)[0].lower(),"newElgamal", suffix3])
        numpy.savez(os.path.join(app.config['UPLOAD_FOLDER'], f'{keynamee}'), e = e)   
                #------------------------- QR Code ----------------------------
        nameqrcode = "_".join(["qr", filename.rsplit('.',1)[0].lower(), suffix2])
        qr = qrcode.make(f'{keynamee}')
        qr.save(f"{nameqrcode}")
        image_rectangle = fitz.Rect(20,450,120,550)
        file_handle = fitz.open(pdffile)
        first_page = file_handle[0]
        first_page.insert_image(image_rectangle, filename = nameqrcode)
        file_handle.save(os.path.join(app.config['UPLOAD_FOLDER'], newfilename)) 
            #----------------- PRINT ----------------
        print("Pesan :\n", teks)
        print("hash:\n ", hash_teks)
        print("Message Digest :\n",hex_hash_teks)
        print("Encrypted :\n",e)
        print("Key File :\n", keynamee)
        pdffile.close()
        flash(newfilename)
        return render_template("template.html",scroll='scrollspyHeading3')
    return render_template("template.html",scroll='scrollspyHeading3')

@app.route("/runscriptdec", methods=['POST'])
def run_scriptdec():
    if request.method == 'POST':
        if 'filesdec[]' not in request.files:
            flash('No file part')
            return render_template("template.html")
        files = request.files.getlist('filesdec[]')
        uploadfile = []
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            uploadfile.append(filename)
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]), allow_pickle=True) as data:
            x = data['x']
            p = data['p']
            nbits = data['nbits']
        x = int(x)
        p = int(p)
        nbits = int(nbits)    
        print(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]))     
        pdf = open(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[1]), 'rb')
        pdfFile = fitz.open(pdf)
        pdfReader = PyPDF2.PdfFileReader(pdf)
        pageObj = pdfReader.getPage(0)
        teks = pageObj.extractText()
                #--------------- Get QR-Code from PDF ----------------
        number_of_page = len(pdfFile)
        for current_page_index in range(number_of_page):
            for img_index, img in enumerate(pdfFile.getPageImageList(current_page_index)):
                xref = img[0]
                image = fitz.Pixmap(pdfFile, xref)
                if image.n < 5:
                    image.writePNG(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
                else:                
                    new_image = fitz.Pixmap(fitz.csRGB, image)
                    new_image.writePNG(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        img = cv.imread(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        det = cv.QRCodeDetector()
        val, pts, st_code = det.detectAndDecode(img)
        with numpy.load(os.path.join(app.config['UPLOAD_FOLDER'], val), allow_pickle=True) as datas:
            e = datas['e']
        e = str(e)
        # print(e)
                #-------------------- olah dari qr --------------------------
        dec = decryption(e,x,p,nbits)
        hasil = ''.join([str(elem) for elem in dec])
                #--------------Hashing Text --------------------------
        hash_teks = hashlib.sha512(teks.encode())
        hex_hash_teks = hash_teks.hexdigest()
                #----------------------Compare Hash---------------------
        cekhasil = cek(hasil, hex_hash_teks)
        print("Pesan :\n", teks)
        print("Isi QR-Code :\n", val)
        print("Rujukan link QR-Code :\n", e)
        print("Message Digest :\n", hex_hash_teks)
        print("Decryption Result :\n", hasil)
        print("Verification Result: \n", cekhasil)
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], uploadfile[0]))
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], "imageQR.png"))
        flash(cekhasil)
        return render_template("template.html",scroll='scrollspyHeading4')

@app.route("/download", methods=['GET', 'POST'])
def download():
    if request.method == 'POST':
        filename = request.form['form']
        uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'],filename)
    return send_file(uploads,as_attachment=True)
   
@app.route("/delete", methods=['GET', 'POST'])
def delete():
    uploads = os.path.join(current_app.root_path, app.config['UPLOAD_FOLDER'])
    for file in os.scandir(uploads):
        os.remove(file.path)
    return render_template("template.html",**locals())

if __name__ == "__main__":
    app.run(debug=True)